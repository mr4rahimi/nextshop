import "@/app/globals.css";
import { myFont } from "@/app/fonts";
import { ThemeProvider } from "@/components/layout/ThemeProvider";
import { prisma } from "@/lib/prisma";
import { SITE_URL } from "@/lib/seo";
import type { Metadata, Viewport } from "next";
import AiChat from "@/components/AiChat";

function buildCssVars(theme: Record<string, string>): string {
  if (!theme || Object.keys(theme).length === 0) return "";
  const vars = Object.entries(theme)
    .map(([key, value]) => `  ${key}: ${value};`)
    .join("\n");
  return `:root {\n${vars}\n}`;
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
};

export async function generateMetadata(): Promise<Metadata> {
  try {
    const s = await prisma.storeSettings.findUnique({ where: { id: "singleton" } });
    const name = s?.storeName ?? "مانا شاپ";
    const googleVerify = process.env.NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION;
    return {
      metadataBase: new URL(SITE_URL),
      title: { default: name, template: `%s | ${name}` },
      description: s?.siteDescription ?? "فروشگاه اینترنتی",
      keywords:    s?.siteKeywords    ?? undefined,
      icons: s?.siteFavicon
        ? { icon: s.siteFavicon, shortcut: s.siteFavicon }
        : { icon: "/favicon.ico" },
      verification: googleVerify ? { google: googleVerify } : undefined,
      openGraph: {
        title:       s?.storeName       ?? "مانا شاپ",
        description: s?.siteDescription ?? "",
        siteName:    s?.storeName       ?? "مانا شاپ",
        url:         SITE_URL,
        locale:      "fa_IR",
        type:        "website",
      },
    };
  } catch {
    return { metadataBase: new URL(SITE_URL), title: "مانا شاپ", description: "فروشگاه اینترنتی" };
  }
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  let cssVars = "";
  try {
    const s = await prisma.storeSettings.findUnique({
      where: { id: "singleton" },
      select: { themeConfig: true },
    });
    if (s?.themeConfig && typeof s.themeConfig === "object") {
      cssVars = buildCssVars(s.themeConfig as Record<string, string>);
    }
  } catch {}

  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem('theme');var d=window.matchMedia('(prefers-color-scheme:dark)').matches;if(t==='dark'||(!t&&d)){document.documentElement.classList.add('dark')}}catch(e){}})()`,
          }}
        />
        {cssVars && (
          <style dangerouslySetInnerHTML={{ __html: cssVars }} />
        )}
        <link rel="stylesheet" href="/assets/js/plugin/swiper/swiper-bundle.min.css" />
        <script src="/assets/js/plugin/swiper/swiper-bundle.min.js" defer></script>
      </head>
      <body className={`${myFont.className} bg-white dark:bg-[#050505] text-gray-900 dark:text-gray-100 min-h-screen transition-colors duration-300`}>
        <ThemeProvider>
          {children}
        </ThemeProvider>
        <AiChat />
      </body>
    </html>
  );
}
